from django.shortcuts import redirect, render,get_object_or_404
from django.contrib.auth import login, authenticate,logout
from django.contrib.auth.models import Group
from django.views.generic import View
from .forms import *
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator


# reg view

class MakerRegistrationView(View):
    def get(self, request):
        form = MakerRegistrationForm()
        return render(request, "maker_reg.html", {'form': form})

    def post(self, request):
        form = MakerRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            checker = form.cleaned_data.get('checker')
            maker_group, created = Group.objects.get_or_create(name='Maker')
            maker_group.user_set.add(user)
            Maker.objects.create(user=user, checker=checker)
            messages.success(request, 'Registration successful. You can now log in.')
            return redirect('log')
        return render(request, 'maker_reg.html', {'form': form})


class CheckerRegistrationView(View):
    def get(self, request):
        form = CheckerRegistrationForm()
        return render(request, "checker_reg.html", {'form': form})

    def post(self, request):
        form = CheckerRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            checker_group, created = Group.objects.get_or_create(name='Checker')
            checker_group.user_set.add(user)
            Checker.objects.create(user=user)
            messages.success(request, 'Registration successful. You can now log in.')
            return redirect('log')
        return render(request, 'checker_reg.html', {'form': form})


# log
class CustomLoginView(View):
    def get(self, request):
        form = CustomAuthenticationForm()
        return render(request, 'main.html', {'form': form})

    def post(self, request):
        form = CustomAuthenticationForm(data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                if user.groups.filter(name='Checker').exists():
                    return redirect('checker_dashboard')
                elif user.groups.filter(name='Maker').exists():
                    return redirect('maker_dashboard')
                else:
                    messages.error(request, "You don't have the necessary permissions.")
            else:
                messages.error(request, "Invalid username or password.")
        return render(request, 'main.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('log')


class MakerDashboardView(LoginRequiredMixin, View):
    template_name = 'maker_dash.html'

    def get(self, request):
        try:
            maker = Maker.objects.get(user=request.user)
            customers = Customer.objects.filter(maker=maker)
        except Maker.DoesNotExist:
            return render(request, self.template_name, {'error': 'Maker profile does not exist.'})

        return render(request, self.template_name, {'customers': customers})


class UploadCustomerView(View):
    form_class = CustomerForm
    template_name = 'upload_customer.html'

    def get(self, request):
        form = self.form_class()
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        form = self.form_class(request.POST, request.FILES)
        if form.is_valid():
            customer = form.save(commit=False)
            customer.maker = Maker.objects.get(user=request.user)
            customer.save()
            return redirect('maker_dashboard')
        return render(request, self.template_name, {'form': form})
 

class CheckerDashboardView(LoginRequiredMixin, View):
    template_name = 'checker_dash.html'

    def get(self, request):
        try:
            checker = Checker.objects.get(user=request.user)
            customers = Customer.objects.filter(maker__checker=checker)
            return render(request, self.template_name, {'customers': customers})
        except Checker.DoesNotExist:
            messages.error(request, "Checker profile does not exist.")
            return redirect('log')


class ApproveCustomerView(LoginRequiredMixin, View):
    def post(self, request, customer_id):
        customer = get_object_or_404(Customer, id=customer_id)
        customer.status = 'Approved'
        customer.save()
        messages.success(request, f"Customer {customer.full_name} has been approved.")
        return redirect('checker_dashboard')



class DeclineCustomerView(LoginRequiredMixin, View):
    def post(self, request, customer_id):
        customer = get_object_or_404(Customer, id=customer_id)
        customer.status = 'Declined'
        customer.save()
        messages.success(request, f"Customer {customer.full_name} has been declined.")
        return redirect('checker_dashboard')
        

from django.urls import path
from .views import *

urlpatterns = [
    path("",CustomLoginView.as_view(),name="log"),
    path("maker_registration/",MakerRegistrationView.as_view(),name="maker_reg"),
    path("checker_registration/",CheckerRegistrationView.as_view(),name="checker_reg"),
    path('maker_dashboard/', MakerDashboardView.as_view(), name='maker_dashboard'),
    path('upload_customer/', UploadCustomerView.as_view(), name='upload_customer'),
    path('checker_dashboard/', CheckerDashboardView.as_view(), name='checker_dashboard'),
    path('approve_customer/<int:customer_id>/', ApproveCustomerView.as_view(), name='approve_customer'),
    path('decline_customer/<int:customer_id>/', DeclineCustomerView.as_view(), name='decline_customer'),
    path('logout/', logout_view, name='logout'),
    
]

from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import Maker, Checker, Customer, CustomerStatus

admin.site.register(Maker)
admin.site.register(Checker)
admin.site.register(Customer)
admin.site.register(CustomerStatus)
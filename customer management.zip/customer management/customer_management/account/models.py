from django.db import models
from django.contrib.auth.models import User

# Create your models here.

# checker
class Checker(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.user.username
    
# maker  
class Maker(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    checker = models.ForeignKey(Checker, related_name='makers', on_delete=models.CASCADE)
    
    def __str__(self):
        return self.user.username
    
# customer
class Customer(models.Model):
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Approved', 'Approved'),
        ('Declined', 'Declined'),
    ]
    
    maker = models.ForeignKey(Maker, related_name='customers', on_delete=models.CASCADE)
    full_name = models.CharField(max_length=100)
    photo = models.ImageField(upload_to='customer_photos/')
    resume = models.FileField(upload_to='customer_resumes/')
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='Pending')
    
    def __str__(self):
        return self.full_name
    
class CustomerStatus(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    status = models.CharField(max_length=10, choices=Customer.STATUS_CHOICES)
    timestamp = models.DateTimeField(auto_now_add=True)
    
# views not created yettt